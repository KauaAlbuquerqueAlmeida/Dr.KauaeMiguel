Miguel Borges da silva N°21; Kauã albuquerque almeida N°16

para esse app funcionar precione -ctrl e "- para abrir o terminal escreva

npm install;

depois instele: 

npx expo install react-native-web@~0.18.10 react-dom@18.2.0
npx expo install @expo/webpack-config@^18.0.1



login para entrar é:professor@escola.com
senha: 123456